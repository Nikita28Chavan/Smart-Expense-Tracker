import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        ExpenseManager manager = new ExpenseManagerImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== SMART EXPENSE TRACKER =====");
            System.out.println("1. Add Expense");
            System.out.println("2. View All Expenses");
            System.out.println("3. View Category-wise Summary");
            System.out.println("4. View Monthly Total");
            System.out.println("5. Delete Expense");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Amount: ");
                    double amount = sc.nextDouble(); sc.nextLine();
                    System.out.print("Enter Category (Food, Travel, Shopping, etc.): ");
                    String category = sc.nextLine();
                    System.out.print("Enter Description: ");
                    String desc = sc.nextLine();
                    manager.addExpense(amount, category, desc);
                    break;

                case 2: manager.viewExpenses(); break;
                case 3: manager.viewCategorySummary(); break;
                case 4: manager.viewMonthlyTotal(); break;

                case 5:
                    System.out.print("Enter Expense ID to delete: ");
                    int id = sc.nextInt();
                    manager.deleteExpense(id);
                    break;

                case 6:
                    System.out.println("Thank you for using Smart Expense Tracker!");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Try again!");
            }
        }
    }
}
